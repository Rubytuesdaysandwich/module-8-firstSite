<footer>
      &copy; <?php echo date('Y');?> Globe Bank
  </footer>

  </body>
</html>
