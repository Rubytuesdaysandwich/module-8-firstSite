<?php require_once('../../../private/initialize.php');?><!--file path to initialize.php use static string not dynamic data-->

<?php $page_title='subjects';?>
<?php include(SHARED_PATH .'/staff_header.php');?><!--file path to private/shared/ staff_header-->
<div id="content">

</div>

<?php include(SHARED_PATH .'/staff_footer.php');?><!--file path to private/shared/ staff_header-->